namespace dotnet_rpg.Models
{
    public enum RpgClass
    {
        Knight,

        Mage,

        Cleric
    }
}